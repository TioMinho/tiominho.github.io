## (CHEM-E7225 Advanced Process Control)
# Exercise 4 - (Constrained) Receding-horizon control w/ CasADi 

# PROBLEM STATEMENT ------------------------------------------------------
# We will formulate optimal control problems to operate nonlinear systems.
# Consider the continuous-time nonlinear system 
# 
#   [dx1/dt] = [          x2          ]
#   [dx2/dt]   [ -sin(x1) - 0.5x2 + u ]
#
# We want to drive this system to the (unstable) equilibrium point 
# x_ref = [pi, 0] and u_ref = 0. For this purpose, we will design a 
# setpoint-tracking L-MPC law , given the linear-quadratic problem 
#
#     minimize  \sum_{k=0}^{N-1} [xd[k]]^T[Q  0][xd[k]] + xd[N]^T Q_f xd[N]
#                                [ud[k]]  [0  R][ud[k]]
#
#   subject to  xd[k+1] = A xd[k] + B ud[k],    k = 1,...,N-1
#               xd_min <= xd[k] <= xd_max,      k = 1,...,N-1
#               ud_min <= ud[k] <= ud_max,      k = 1,...,N-1
#               xd[0] = xd_0
#
# The tuning matrices are diagonal, Q = Qf = diag([1, 1]) and R = 10, and
# the control horizon is N = 50. The matrices (A, B) are obtained by 
# linearizing-then-discretizing the nonlinear dynamics at (x_ref, u_ref). 
# The constraints are, in original variables, pi <= x[k] <= pi and
# -2 <= u[k] <= 2 (for all k). Use slack variables for state constraints.
# The controller has a frequency 1/dt = 10 Hz. Simulate the closed-loop 
# system with initial state x_0 = (-1.5,-1.5) and horizon T = 30s.
# 

# SOLUTION ---------------------------------------------------------------
from casadi import Opti
from numpy import array, sin, pi, linspace, zeros, vstack
import control as ct
import matplotlib.pyplot as plt

# Since the system is nonlinear, we define its dynamics using a function
#  with arguments (t, x, u, params)---this is the common convention
def f(t, x, u, params):
    return array([x[1], 
                  -sin(x[0]) - 0.5*x[1] + u[0]])  

pendulum = ct.nlsys(f)

#  We linearize-then-discretize this model using the `controls` package
dt = 0.1        # (play with different values!)
x_ref = [pi, 0]
u_ref = [0]

pendulum_lin = pendulum.linearize(x_ref, u_ref).sample(dt)
A, B = pendulum_lin.A, pendulum_lin.B

# The controller is created by formulating the equivalent NLP (using Opti),
#   then creating a function that returns the first solution u[0] given a
#   value for the problem parameter xd_0
N = 50
Q = Qf = array([[1, 0], [0, 1]])
R = 2

xmin, xmax = -pi, pi
umin, umax = -1, 1

OCP = Opti()

x  = OCP.variable(2,N  )
e  = OCP.variable(2,N  )
u  = OCP.variable(1,N-1)

x0 = OCP.parameter(2,1)

# Value function
V_N = x[:,-1].T@Qf@x[:,-1]
for k in range(N-1):
	V_N += x[:,k].T@Q@x[:,k] + u[:,k].T@R@u[:,k] + 1e6*e[:,k].T@e[:,k]

OCP.minimize( V_N )

for k in range(N-1):    
	OCP.subject_to( x[:,k+1] == A@x[:,k] + B@u[:,k] )
	OCP.subject_to( OCP.bounded(xmin-e[:,k], x[:,k]+x_ref, xmax+e[:,k]) )
	OCP.subject_to( OCP.bounded(umin, u[:,k]+u_ref, umax) )
	OCP.subject_to( e[:,k] >= 0 )

OCP.subject_to( x[:,0] == x0 )  # Boundary conditions

OCP.solver('ipopt', {'print_time': 0, 'ipopt': {'print_level': 0}})
K_RHC = OCP.to_function('K_RHC', [x0], [u[:,0]])

# We now simulate the nonlinear system, using the optimal control policy
#   created above to compute the control actions in real-time
#   (we overwrite the vars from the OCP, since not needed anymore)
N = int(30/dt)
x = zeros((2,N  ))
u = zeros((1,N-1))

# In this part of the code, we write the basic simulation loop in which
#   both the inputs u(:,n) and state transitions x(:,n+1) are computed
x[:,0] = [-1.5, -1.5]
for n in range(N-1):
    u[:,n] = u_ref + K_RHC(x[:,n] - x_ref).full()[0]                                  # Control policy
    x[:,n+1] = ct.input_output_response(pendulum, [0, dt], u[0,n], x[:,n]).x[:,-1]    # State transition


# VISUALIZATION ----------------------------------------------------------
plt.figure(figsize=(10,4))

ax1 = plt.subplot(1,2,1); ax1.plot(u[0,:],         lw=1, c="#56adbc")
ax2 = plt.subplot(1,2,2); ax2.plot(x[0,:], x[1,:], lw=1, c="#c4265e"); ax2.plot([pi], [0], 'kx')

ax1.set_xlabel("Timesteps - $n$");  ax1.set_ylabel("Input - $u[n]$") 
ax2.set_xlabel("State - $x_1[n]$"); ax2.set_ylabel("State - $x_2[n]$")

plt.tight_layout()
plt.show()