## (CHEM-E7225 Advanced Process Control)
# Exercise 1 - Simulation of Dynamical Systems

# PROBLEM STATEMENT ------------------------------------------------------
# Consider the discrete-time LTI system 
# 
#   [x1[n+1]] = [ 0.9288  0.0833] [x1[n]] + [0.0737] u[n]
#   [x2[n+1]]   [-1.3331  0.6622] [x2[n]]   [1.4068]
#
# Simulate the state response of this system given the initial state 
# x[0] = [0, 0] and constant step input u[n] = 1, for n = 0,...,50. 

# SOLUTION ---------------------------------------------------------------
from numpy import array, zeros

# Since an LTI system is fully determined by the matrices (A,B), we just
#  need to create those two variables separately.
A = array([[ 0.9288, 0.0833],
           [-1.3331, 0.6622]])
B = array([[0.0737],
           [1.4068]])

# In this course, we take the convention that signals are represented as 
#   matrices with x[i,n] ~> 'the ith component of x[n]'
N = 50
x = zeros((2,N  ))
u = zeros((1,N-1))  # the inputs stop at N-1, since we don't compute x[N+1]

# In this part of the code, we write the basic simulation loop in which
#   both the inputs u(:,n) and state transitions x(:,n+1) are computed
x[:,0] = [0, 0]
for n in range(N-1):
    u[:,n] = 1;                         # Control policy
    x[:,n+1] = A@x[:,n] + B@u[:,n];     # State transition

# VISUALIZATION ----------------------------------------------------------
# The results are visualized using time-series plots, with stairs for the
#   discrete-time/digital signals
import matplotlib.pyplot as plt

plt.figure(figsize=(10,4))

plt.subplot(1,2,1)
plt.stairs(u[0,:])
plt.xlabel("Timestep - $n$");  plt.xlim([0, N-1])
plt.ylabel("Inputs - $u[n]$"); plt.ylim([0, 2])

plt.subplot(1,2,2)
plt.stairs(x[0,:].T)
plt.stairs(x[1,:].T)
plt.xlabel("Timestep - $n$"); plt.xlim([0, N])
plt.ylabel("State - $x[n]$")
plt.legend(["$x_1$", "$x_2$"])

plt.show()