## (CHEM-E7225 Advanced Process Control)
# Exercise 1 - Simulation of Dynamical Systems

# PROBLEM STATEMENT ------------------------------------------------------
# Consider the continuous-time nonlinear system 
# 
#   [dx1/dt] = [          x2          ]
#   [dx2/dt]   [ -sin(x1) - 0.5x2 + u ]
#
# Obtain a linearized model dx(t)/dt = Ax(t) + Bu(t) [which is now in
# deviation variables] with steady-state (x_ss, u_ss) = ([0, 0], [0]).
# Then, discretize this linearization with dt = 0.1 [units-of-time]
# and simulate its response for initial state x(0) = [4, -1.5] and 
# input signal u(t) = 0.2sin(t), t \in (0, 30). 
#
# Compare the response with that obtained from Exercise 01-3.

# SOLUTION ---------------------------------------------------------------
from numpy import array, zeros, sin
import matplotlib.pyplot as plt
import control as ct

# Since the system is nonlinear, we define its dynamics using a function
#  with arguments (t, x, u, params)---this is the common convention
#  We linearize-then-discretize this model using the `controls` package
def f(t, x, u, params):
    return array([x[1], 
                  -sin(x[0]) - 0.5*x[1] + u[0]])  

dt = 0.1        # (play with different values!)
x_ref = [0, 0]
u_ref = [0]
pendulum = ct.nlsys(f).linearize(x_ref, u_ref).sample(dt)

Ad, Bd = pendulum.A, pendulum.B

# In this course, we take the convention that signals are represented as 
#   matrices with x[i,n] ~> 'the ith component of x[n]'
N = int(30/dt)
x = zeros((2,N  ))
u = zeros((1,N-1))

# In this part of the code, we write the basic simulation loop in which
#   both the inputs u(:,n) and state transitions x(:,n+1) are computed
x[:,0] = [4, -1.5]
for n in range(N-1):
    u[:,n] = 0.2*sin(n*dt);             # Control policy
    x[:,n+1] = Ad@x[:,n] + Bd@u[:,n]    # State transition


# VISUALIZATION ----------------------------------------------------------
# The results are visualized using time-series plots, with stairs for the
#   discrete-time/digital signals
plt.figure(figsize=(10,4))

plt.subplot(1,2,1)
plt.stairs(u[0,:])
plt.xlabel("Timestep - $n$");  plt.xlim([0, N-1])
plt.ylabel("Inputs - $u[n]$"); plt.ylim([-1, 1])

plt.subplot(1,2,2)
plt.stairs(x[0,:].T)
plt.stairs(x[1,:].T)
plt.xlabel("Timestep - $n$"); plt.xlim([0, N])
plt.ylabel("State - $x[n]$")
plt.legend(["$x_1$", "$x_2$"])

plt.show()