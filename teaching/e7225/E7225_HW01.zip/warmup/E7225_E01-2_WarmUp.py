## (CHEM-E7225 Advanced Process Control)
# Exercise 1 - Simulation of Dynamical Systems

# PROBLEM STATEMENT ------------------------------------------------------
# Consider the continuous-time LTI system 
# 
#   [dx1(t)/dt] = [  0.0   1.0] [x1(t)] + [ 0] u(t)
#   [dx2(t)/dt]   [-16.0  -3.2] [x2(t)]   [16]
#
# Obtain the equivalent discrete-time system with a discretization period 
# dt = 0.1 [units-of-time]. Using the discretized system, simulate the 
# state given the initial state x(0) = [0, 0] and step input u(t) = 1.
# Simulate until T = 5 [units-of-time], that is, for N = T/dt timesteps.

# SOLUTION ---------------------------------------------------------------
from numpy import array, zeros, vstack, hstack
from scipy.linalg import expm
import matplotlib.pyplot as plt

# Since an LTI system is fully determined by the matrices (A,B), we just
#  need to create those two variables separately.
A = array([[  0.0,  1.0],
           [-16.0, -3.2]])
B = array([[ 0.0],
           [16.0]])

# We discretize the system using the trick from L02 (Appendix)
dt = 0.1    # (play with different values!)
AB_c = vstack([ hstack([A, B]), zeros((1,2+1)) ])
AB_d = expm(AB_c*dt)

Ad = AB_d[0:2,0:2]
Bd = AB_d[0:2,2: ]

# In this course, we take the convention that signals are represented as 
#   matrices with x[i,n] ~> 'the ith component of x[n]'
N = int(5/dt)
x = zeros((2,N  ))
u = zeros((1,N-1))

# In this part of the code, we write the basic simulation loop in which
#   both the inputs u(:,n) and state transitions x(:,n+1) are computed
x[:,0] = [0, 0]
for n in range(N-1):
    u[:,n] = 1;                         # Control policy
    x[:,n+1] = Ad@x[:,n] + Bd@u[:,n];     # State transition

# VISUALIZATION ----------------------------------------------------------
# The results are visualized using time-series plots, with stairs for the
#   discrete-time/digital signals
plt.figure(figsize=(10,4))

plt.subplot(1,2,1)
plt.stairs(u[0,:])
plt.xlabel("Timestep - $n$");  plt.xlim([0, N-1])
plt.ylabel("Inputs - $u[n]$"); plt.ylim([0, 2])

plt.subplot(1,2,2)
plt.stairs(x[0,:].T)
plt.stairs(x[1,:].T)
plt.xlabel("Timestep - $n$"); plt.xlim([0, N])
plt.ylabel("State - $x[n]$")
plt.legend(["$x_1$", "$x_2$"])

plt.show()