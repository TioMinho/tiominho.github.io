## (CHEM-E7225 Advanced Process Control)
# Exercise 1 - Simulation of Dynamical Systems

# PROBLEM STATEMENT ------------------------------------------------------
# Consider the continuous-time nonlinear system 
# 
#   [dx1/dt] = [          x2          ]
#   [dx2/dt]   [ -sin(x1) - 0.5x2 + u ]
#
# Simulate this system using Range-Kutta 4th-Order (RK4) integrator with 
# discretization period dt = 0.1 [units-of-time]. Consider initial state
# x(0) = [4, -1.5] and input signal u(t) = 0.2sin(t), t \in (0, 30). 

# SOLUTION ---------------------------------------------------------------
from numpy import array, zeros, sin
import matplotlib.pyplot as plt

# Since the system is nonlinear, we define its dynamics using a function
#  with arguments (t, x, u, params)---this is the common convention
def f(t, x, u, params):
    return array([x[1], 
                  -sin(x[0]) - 0.5*x[1] + u[0]])  

# The system is discretized using the RK4 integrator 
dt = 0.1    # (play with different values!)

def f_dt(t, x, u, params):
    k1 = f(t, x,           u, params)
    k2 = f(t, x + dt/2*k1, u, params)
    k3 = f(t, x + dt/2*k2, u, params)
    k4 = f(t, x + dt*k3,   u, params)

    return x + dt/6*(k1 + 2*k2 + 2*k3 + k4)

# In this course, we take the convention that signals are represented as 
#   matrices with x[i,n] ~> 'the ith component of x[n]'
N = int(30/dt)
x = zeros((2,N  ))
u = zeros((1,N-1))

# In this part of the code, we write the basic simulation loop in which
#   both the inputs u(:,n) and state transitions x(:,n+1) are computed
x[:,0] = [4, -1.5]
for n in range(N-1):
    u[:,n] = 0.2*sin(n*dt);                         # Control policy
    x[:,n+1] = f_dt(n*dt, x[:,n], u[:,n], [])       # State transition


# VISUALIZATION ----------------------------------------------------------
# The results are visualized using time-series plots, with stairs for the
#   discrete-time/digital signals
plt.figure(figsize=(10,4))

plt.subplot(1,2,1)
plt.stairs(u[0,:])
plt.xlabel("Timestep - $n$");  plt.xlim([0, N-1])
plt.ylabel("Inputs - $u[n]$"); plt.ylim([-1, 1])

plt.subplot(1,2,2)
plt.stairs(x[0,:].T)
plt.stairs(x[1,:].T)
plt.xlabel("Timestep - $n$"); plt.xlim([0, N])
plt.ylabel("State - $x[n]$")
plt.legend(["$x_1$", "$x_2$"])

plt.show()