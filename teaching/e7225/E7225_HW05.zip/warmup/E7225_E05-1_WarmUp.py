## (CHEM-E7225 Advanced Process Control)
# Exercise 5 - Receding-horizon estimation w/ CasADi 

# PROBLEM STATEMENT ------------------------------------------------------
# Consider the continuous-time nonlinear system 
# 
#   [dx1/dt] = [          x2          ] + [w1]
#   [dx2/dt]   [ -sin(x1) - 0.5x2 + u ]   [w2]
#
#          y = x + v
#
# where the continuous-time disturbance/noise become, after discretization, 
# w ~ N(0,Sw^2) and v ~ N(0,Sv^2) with Sw = 0.1sqrt(dt)*I and Sv = 0.1I
#
# We want to estimate the state of this system assuming it is operating 
# around the reference point x_ref = [0, 0] and u_ref = 0. For this purpose, 
# we will design a L-MHE policy, based on the linear-quadratic problem 
#
#     minimize  \sum_{k=0}^{N-1} [ed[k]]^T[Qe  0][ed[k]] + ed[N]^T Q_ef ed[N]
#                                [ud[k]]  [0  Re][ud[k]]
#
#   subject to  xd[k+1] = A xd[k] + wd[k],    k = 1,...,N-1
#
# with the measurement error signal ed[k] = C*xd[k] - y_data,d[k]. 
# The tuning matrices are diagonal, Qe = Q_ef = inv(Sv^2) and R = inv(Sw^2), 
# and the estimation horizon is Ne = 25. The matrices (A, B, C) are obtained
# by linearizing-then-discretizing the nonlinear dynamics at (x_ref, u_ref). 
# The estimator has a frequency 1/dt = 20 Hz. Simulate the estimation of 
# the system with initial state x_0 = (pi,-1.5) and horizon T = 30s.
# 

# SOLUTION ---------------------------------------------------------------
from casadi import Opti
from numpy import array, sin, pi, linspace, zeros, hstack, eye, sqrt
from numpy.linalg import inv
from numpy.random import randn
import control as ct
import matplotlib.pyplot as plt

# Since the system is nonlinear, we define its dynamics using a function
#  with arguments (t, x, u, params)---this is the common convention
def f(t, x, u, params):
    return array([x[1], 
                  -sin(x[0]) - 0.5*x[1] + u[0]])  

def g(t, x, u, params):
    return x

pendulum = ct.nlsys(f, g)

#  We linearize-then-discretize this model using the `controls` package
dt = 0.05        # (play with different values!)
x_ref = array([[0, 0]]).T
u_ref = array([[0]]).T
y_ref = x_ref

pendulum_lin = pendulum.linearize(x_ref, u_ref).sample(dt)
A, B, C = pendulum_lin.A, pendulum_lin.B, pendulum_lin.C

# For convenience, we define the noise/disturbance std-matrices here
Sw = eye(2)*0.1*sqrt(dt)
Sv = eye(2)*0.1

# The estimator is created by formulating the equivalent NLP (using Opti),
#   then creating a function that returns the first solution x_hat[0] given
#   a value for the problem parameter y_data
Ne = 25
Qe = Qef = inv(Sv**2)
Re = inv(Sw**2)

OEP = Opti()

x  = OEP.variable(2,Ne  )
w  = OEP.variable(2,Ne-1)

y_data = OEP.parameter(2,Ne)

# Value function
e = C@x - y_data   # (creates the expression for the error)

V_Ne = e[:,-1].T@Qef@e[:,-1]
for k in range(Ne-1):
    V_Ne += e[:,k].T@Qe@e[:,k] + w[:,k].T@Re@w[:,k]

OEP.minimize( V_Ne )

for k in range(Ne-1):    
	OEP.subject_to( x[:,k+1] == A@x[:,k] + w[:,k] )

OEP.solver('ipopt', {'print_time': 0, 'ipopt': {'print_level': 0}})
K_RHE = OEP.to_function('K_RHE', [y_data], [x[:,-1]])   # (note the different signature)

# We now simulate the nonlinear system, using the optimal estimation policy
#   created above to compute the state estimates in real-time
#   (we overwrite the vars from the OEP, since not needed anymore)
N_sim = int(30/dt)
x = zeros((2,N_sim  ))
y = zeros((2,N_sim  ))
u = zeros((1,N_sim-1))

x_hat  = zeros((2,N_sim))
y_data = zeros((2,Ne))

# In this part of the code, we write the basic simulation loop in which
#   both the inputs u(:,n) and state transitions x(:,n+1) are computed
x[:,0] = y[:,0] = [pi, -1.5]
for n in range(N_sim-1):
    # Estimation policy
    x_hat[:,[n]] = x_ref + K_RHE(y_data - y_ref).full()    
    
    # Control policy
    u[:,n] = 0

    # State transition
    response = ct.input_output_response(pendulum, [0, dt], u[0,n], x[:,n])          
    x[:,n+1] = response.x[:,-1] + Sw@randn(2,)
    y[:,n+1] = x[:,n+1] + Sv@randn(2,)

    # Dataset update
    y_data = hstack([y_data[:,1:], y[:,[n]]])


# VISUALIZATION ----------------------------------------------------------
# (note that we "burn" the first Ne because the estimates are very bad
#   until the y_data batch gets filled with measurements)
plt.figure(figsize=(10,6))

plt.scatter(y[0,:], y[1,:], 5, "black", marker='.')
plt.plot(x[0,:], x[1,:], lw=1, c="#c4265e", alpha=0.2)
plt.plot(x_hat[0,Ne:], x_hat[1,Ne:], lw=1, c="#c4265e")

plt.xlabel("State - $x_1[n]$"); plt.ylabel("State - $x_2[n]$")

plt.legend(["Measurement", "True state", "Estimates"])

plt.tight_layout()
plt.show()