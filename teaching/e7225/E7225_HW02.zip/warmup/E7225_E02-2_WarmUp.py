## (CHEM-E7225 Advanced Process Control)
# Exercise 2 - Nonlinear Programming w/ CasADi  

# PROBLEM STATEMENT ------------------------------------------------------
# An isothermal CSTR of constant volume V, implements the reactions 
# A -> B -> C and C -> 0. The inlet concentrations x_Ai [mol/L] can be 
# manipulated. The constant parameters are the dilution rate q = 1 [1/h], 
# and kinetic rates k_AB = 1 [1/h], k_BC = 1 [1/h], and k_C0= 1.5 [1/h]. 
#
# In this scenario, the sales price of x_C is c_P = 0.5 [€/mol], 
# the cost of feedstock x_Ai is c_F = 0.01 [€/mol], and impurities xB 
# incur in a cost of c_I = 0.01 [€/mol]. Solve problem of finding the 
# steady-state operating point of maximum profit, from the linear program
# 
#     minimize  c_P*x_C - (c_I*x_B + c_F*x_Ai)
#
#   subject to  [(x_Ai-x_A) - k_AB*x_A           ] = [0].  [x_A ] >= [0], x_Ai <= 10
#               [     -x_B  + k_AB*x_A - k_BC*x_B]   [0]   [x_B ]    [0]
#               [     -x_C  + k_BC*x_B - k_C0*x_C]   [0]   [x_C ]    [0]
#                                                          [x_Ai]    [0]
#

# SOLUTION ---------------------------------------------------------------
from casadi import Opti
from numpy import array, linspace, zeros, vstack
import matplotlib.pyplot as plt

# (Here we define the matrices A and H, and the vector c)
k_AB, k_BC, k_C0 = (1, 1, 1.5)
c_P, c_F, c_I = (0.5, 0.01, 0.01)

c = array([[0, c_I, -c_P, c_F]]).T
d = 0

A = array([[-(1+k_AB),      0   ,     0    , 1],
           [   k_AB  , -(1+k_BC),     0    , 0],
           [    0    ,    k_BC  , -(1+k_C0), 0]])

b = array([[0, 0, 0]]).T

H = array([[-1,  0,  0,  0],
           [ 0, -1,  0,  0],
           [ 0,  0, -1,  0],
           [ 0,  0,  0, -1],
           [ 0,  0,  0,  1]])

h = array([[0, 0, 0, 0, 10]]).T

# (Use OptiStack to formulate and solve the problem)
NLP = Opti()
x = NLP.variable(4,1)

NLP.minimize( c.T@x + d )
NLP.subject_to( A@x - b == 0 )
NLP.subject_to( H@x - h <= 0 )

NLP.solver('ipopt')
NLP.solve()

p_star = NLP.value(NLP.f)
x_star = NLP.value(x)

print("Value: ", p_star, ", Optimizer: ", x_star)
