## (CHEM-E7225 Advanced Process Control)
# Exercise 2 - Nonlinear Programming w/ CasADi  

# PROBLEM STATEMENT ------------------------------------------------------
# Write the following quadratic problem in standard form, then solve it 
# using CasADi's OptiStack (see https://web.casadi.org/docs/):
# 
#     minimize  [x1]^T[2 0][x1] + [-2]^T[x1] + 5 
#               [x2]  [0 6][x2]   [-3]  [x2]
#
#   subject to  x1 + x2 = 1, 
#               x >= 0
#

# SOLUTION ---------------------------------------------------------------
from casadi import Opti
from numpy import array, linspace, zeros, vstack
import matplotlib.pyplot as plt

# (Here we define the matrices P,A, and H, and the vector q)
P = array([[2, 0], 
           [0, 6]])
q = array([[-2], 
           [-3]])
r = 5

A = array([[1, 1]])
b = array([1])

H = array([[-1,  0],
           [ 0, -1]])
h = array([[0],
           [0]])

# (Use OptiStack to formulate and solve the problem)
NLP = Opti()
x = NLP.variable(2,1)

NLP.minimize( (1/2)*x.T@P@x + q.T@x + r )
NLP.subject_to( A@x - b == 0 )
NLP.subject_to( H@x - h <= 0 )

NLP.solver('ipopt')
NLP.solve()

p_star = NLP.value(NLP.f)
x_star = NLP.value(x)

print("Value: ", p_star, ", Optimizer: ", x_star)

# VISUALIZATION ----------------------------------------------------------
# We plot the cost surface (masking the region outside the inequality 
#   constraints) and the line representing the equality constraints.
N = 100; L = 50; # datapoints / level curves
f_func = lambda x: (1/2)*x.T@P@x + q.T@x + r
h_func = lambda x: H@x - h

x1 = x2 = linspace(-1,3,N)
p = zeros((N,N))
feas = zeros((N,N))

for i in range(N):
    for j in range(N):
        x_ij = vstack([x1[i], x2[j]])
        
        p[i,j]    = f_func(x_ij)[0,0]
        feas[i,j] = all(h_func(x_ij) <= 0)

plt.figure()
plt.contourf(x1, x2, p, levels=L)
plt.contourf(x1, x2, feas, levels=3, colors=["#0005", "#FFF0"])
plt.plot(x1, 1-x1, lw=1, color="red"); # plot the equality constraints
plt.xlabel("Decision variable - x_1 [-]"); plt.xlim((-1,3))
plt.ylabel("Decision variable - x_2 [-]"); plt.ylim((-1,3))
plt.show()